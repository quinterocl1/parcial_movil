import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'home_page_model.dart';
export 'home_page_model.dart';

class HomePageWidget extends StatefulWidget {
  const HomePageWidget({Key? key}) : super(key: key);

  @override
  _HomePageWidgetState createState() => _HomePageWidgetState();
}

class _HomePageWidgetState extends State<HomePageWidget> {
  late HomePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  final _unfocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => HomePageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    _unfocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(_unfocusNode),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Color(0xFFF8FBFF),
        body: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
                      child: Text(
                        'BARBER SHOP',
                        textAlign: TextAlign.center,
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Open Sans Condensed',
                              fontSize: 25.0,
                              fontWeight: FontWeight.w900,
                            ),
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Container(
                      width: 100.0,
                      height: 350.0,
                      decoration: BoxDecoration(
                        color: FlutterFlowTheme.of(context).secondaryBackground,
                      ),
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 20.0, 0.0, 20.0),
                        child: Image.network(
                          'https://img.freepik.com/vector-premium/plantilla-logotipo-barberia-vintage_441059-25.jpg?w=2000',
                          width: 100.0,
                          height: 100.0,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(10.0, 0.0, 10.0, 0.0),
                      child: Container(
                        width: 100.0,
                        height: 120.0,
                        decoration: BoxDecoration(
                          color: Color(0xFF999999),
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                        child: Text(
                          'TU BARBERIA DE CONFIANZA',
                          textAlign: TextAlign.center,
                          style:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Open Sans Condensed',
                                    fontSize: 40.0,
                                    fontWeight: FontWeight.bold,
                                  ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 10.0),
                      child: Container(
                        width: 100.0,
                        height: 150.0,
                        decoration: BoxDecoration(
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                        ),
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              10.0, 0.0, 10.0, 0.0),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20.0),
                            child: Image.network(
                              'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFBcVFRUYGBcZHBgXGRoYGRcXGRkaFxcZGBkXGRoaICwjGh0pIBcXJDYkKS0vMzMzGSI4PjgyPSwyMy8BCwsLDw4PHRISHTQpIikyMjIvMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/AABEIAOEA4QMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAEBQIDBgABB//EAEAQAAIBAwIEBAQDBgQFBAMAAAECAwAEERIhBRMxQQYiUWEUcYGRIzKhB0JSscHwFXLR4RYzYsLxJIKS0lNjov/EABkBAAMBAQEAAAAAAAAAAAAAAAABAgMEBf/EACcRAAICAQQCAQMFAAAAAAAAAAABAhEhAxIxURNBYQQUcTJSgZHw/9oADAMBAAIRAxEAPwBFHdbYpZxG2Db1WJcVIz5FRQ0D2yldhRLyleoI+YIqETbnrgldxjsc439fbf0pmbfmYUsyg7sFAGdOkYLY23375yfSolqbHk3ho742uRX8XViXdPoeC2hDFgcIfP5nGnyasZPUYIbI7nHtVUvBrcqpjDaWClX1EEjGQ2luhYYz6eg75r6qLdU/9kr7WXCaAI7qr+Zmh5IVBKquCPUn0ByMkbYPt0NURzVtGaksGU9NweQ5BvT2xFZ+3fJp/ZnasZLJcXgbo1U3Mm1cr7UFdyU4oTYJIjNkhSQOpAJAz6+lD3EpPXsAOg6AYHSrlkYZ0sRnY4JGfnjrQsymtuCAa8nRlxpClV2I31Nkfm9savrQd4BcPHHFEsQCHdmPnx+aR3x67bDavL9WUlWBBHUHYj5jtSp52GACcDOAd182x2O2+32qa6HfYNPIzlVJB0+Rfygbn12GMnqa9ubZ1wjhFIOBuoODk6sjZ1P8WT0xtnc57eJLQMwczyv+HswURKcMQejZIx9a6Lg9wGjcxjMgLRmTluJMozdHJB2BO42OPaqUl+CXFgJCuYkyi4GkyYb/ANusE426ZAG3XNOeDwTRaGO0YlAIb8pcr08vm3HpkHbY1XbxoI4pCyatQI5RV5EA7vG3TGkHcEHcbaqYWVjJJpkCay0hHNCyBdZwFIRVAyCNWFB2YbVEpYr0VGKTs1P7Qo5BZQmVlZuYScKV0kofL5mLE9evoNh0r5XO5OAewxj0A7V9g/aWCLOIZBIkIYk6vMUORuTv8ztXx9h6E99/51Wl7J1PRUDipLU0jolLc9gfnWrZmkULHVipnf7UXFak0wtuHE/m7f3is3NItQYtSAnYUQ1rjAXJOxz860kPCdumMY+9MY7DAJx5sVm9Q0UDHfCt611a/wCDP8I+1dU+RlbUYt6qL0VIlCSLW5gi6GQgE7Fc5/MVOem2Dv16HNFpcScxSjL5ATIGYiNFOAAx3OsnAGxJx0xmhbK11FTjO+dvb29tz9qKmdpVjSMYDrzGwSNRLMoLD2Crt2LNuc1Lipco0U5RqmF2/HCiuqxrIGOdQVkUEKFwqgFmACgamIO35RVPE+PsIo3jRE0Ny3TcggLlApO4wM5/9vrgt7DwtHB+PfA8lFL6WZ01kDZARv64Udcd+lNPEd9Z3UctpFapEkHMUO2iMRlCyatEYJHn3wxDEHodRqfBC7oPNNcMx0t8XOtCh1bqemDgDB7E4xt60EjkbHt9ana5ZHhdDrg8rEdMhtAYk9N9I/8AOALImlyvy98Z3xTSUcIJTcuR1Yvk1orRtqy9ga0Ns9S0CY0L7UFKcmps9QQZNNAzwR0Lcpim6x7ULcx7U2wRnL+1ZSQRg9xsSPYgdD7HelbPkgFQRntgE52xmn1+hJz3PXtQRikizgL+IuMkK/lPXGc4z0NTZQttIPxhhcEN+UYLdcYT1cZ29x7UfYR68SEjlxza5TI+mQ806QQUXX+Xc4LEnOBtvVsT5o12D/kAQksPKTjbAODgD1FNeCcEWVJC+mIgq6yO2hSMkFN8hhlfQ4pSftgl0XWmbRiqNykmIcOqsHEQLYXWy57A6QP3t609jw6MxqedriwBEwEisGGQxAz2Ht0B+ovDrWK6uAWWRuWoAMcYUSlDg5K7KvQg7behIFarlRRqqamdgNo9eUGOgYn82NhnrsKzcW0UpJMwv7T7t+ZywxMSiNsY2DFTnB9xg/SvnwGo1qPHc7G5YMf4e52IUD+/lSDh6b/pXTFbYmEssttLQlhWnt+EHAGeoz6/pSi1xrH9/atZYSnAOPqf5fKspyZrGKBoeDjHzx9hR0NuoOBsdquQep/vqa9UgHoKybNEgpUXYAfM1asK9BUorWQjPLbHyqRXTswIPuKV1yVsKfhh611W6h711G5C2s+dXMVASR07uY6XvHXUcoDaymOQHGQdiCM5BGOntnP0o/gN98PPCHAMlu5R4nKo0kfMJGhn8pbznykg+VcZycVwNy3D6dWN8e46frTHiPDEugjSkI7rrWSMcwAb+V0XzYBBBGMgjO4NRLUcZKLWO/k2jo7tNyTyvRsv2icYt7mGNobiTmRlmVEQAhhsxZsB42TocHuRjPTHJ4ruFgMRYShz5mkCM+UKlSWYEnB1YJJ7fWu24ZxNF0I8VzDnDhJomDgAgIxchxjJwCNielTh4MBnmLoc4GiOZJ5M9gwVNC/VsmtW0lbZjGLbpLII9xohlkGly6wwasZdGUMzM5O/mwwVv4VUdQRSCEZNai9/9PFpRVCyAnzMGlJjygZgAAq5LgKRn8xrP2yb1EJbr69Gupp7KTeffwMrEU6gNLbNKbwJTZmWrRUceDjIPuNxUESiokoGXYGBjOe/p7YoWYUVtVGkscDc/wCm9JjQult80P8AAkg4UnG59hTcR0dwzhyykqWAx1wMke3p3pUFmbltVMaAOzEE+UrgLnrg53rT8E4QiovNyyuupEbYjOCzKVOQhGBv1z0om/4GFKuMFAQGCjBx6nJ3z0r1+I4PMkwqHSFxuBsfKN/RT09Klr0yk74DVhWOArGNC6hsCe7YOTn+deG5jQAsyjvtnO5AGMZPesf4g8Yo8WlBjDZydugOw64PXeslN4rkIICjcY1EnPTsBtjv9vSrUW+CZPbyMfHMRMzybFTggg5I8oxq9z1pOibLjoavsr0yoOYc7tFJ76/NG598gr9aJ4JANGGGSjMv69aqWETHLLOG2xJDHYD9d/5U/gfsKHCn6damjYz7Vg3ZskHo+1O+FQpHHzpBk/ug9vekFnFzGAHc4/1p3x9/IqL3KqB7VlJ1lG+nHc0mWHxLIT5U2otOJpJ5JFwexpNOAkeBSC4aZiGU4AP8qlOXtnQ4wfCo3fwSfx11ZD/EJfWupWRsXYFcx0A8dNZxQbrXceaL5Yat4TxJraQSBFcjI3ztkYJGCN8Ej6miim1Cyw03FSWRx1JQeGaWLxXZsMSW2O42zvjGfKN+9D3HjQJGEgj3AxrYYwcYJAyf5b96zTW9R5FYr6aKlu9mj+ok1QFxC4aV2kfGWYsQNgCxycV5bJVtxFVkC1txhGTbbtjC2WmkFLIDRsT0gGaGiFal6TVZz6BhMj7VXDcFTqU4OCPoQQf0JqpHZjpXckYPTGD8/wC9qPtuEZ/PIB7KM/qaKsLJWCKxIIYnS2kKNywGwPoPemnBoljXBQo2PMcjBbqTjORmqfhIV/cBPqfMfpnp9Kovb9R1IwFxvv09c9fvTqhXZPxVxA6VRHKquZJDnGpEGeXn1Y4FfNOJcUM3mwFGfKqnSoA6HGdzuelH+JPEKyjlhQFxpOlt89c4PbYVk3nJwM7DYew3/wBaNtuxqW0excRTlrG8SSAADLDDDck4Ye59+1KeKCPKmNNGQcrktvnqCf72odLpumx+YFe3coJx5du650n5ZFaJUZSlYdwpWQM+U0lfy6gWLKQRhRkjv1x1O9OOHSjU3cEhh8iB/UVmbS407Ufwu6/EI7Hp7Y7VM1aHB00bBXGPapIdqDWT+/lU1kx/WuZo6UaLgTDVnsBkfyou4fmSD0UZ+p6Uks7jA770weUrHK3fb+QrF8nTprFkb+7RR5jmkvEeLvgRxDTqwMkZO+30q+Kyd2DN8x7V1zaxo6u7jy+Yj5U1S5Kl0X/At/Ea6qP+IovU/Y11Kvgizx2oWRqibigp567DhD0evGNLY7qpm5qoiYURUSoob4iu+IqiS14wagttXgnqQnpUOyxUxUteKqM9UyzUqHYYt1XPeYFJJLrFQjuCTk0qHZpuGT48x6n3/SnsF571jI73FEpxH3poTNdJc570i4655ZPYZ74oZOI+9X/FKwwdxTEYDQzl2xsNzv07CqM1sX4ChDiNyA5BIONsdgfSvbXwlET52l+hT/600xOPRjc044V4emm30lV7EjBPyzW24f4dt4iGT8w7yBXPyG2309au4nxAJ+UAfLb+VJz6BQ7MnxHgAiXJz77j/Ws6rlGBHY0/4vxdnBXJ7H6jP+ppAiF2wBkk4px4yKXODV2MupQQdj/XtRIOD/MfyqVxwU2sULZJLFklBxiOUYYKMdijA991aqkbPWud/B0L5GaHy59KdIgdPaRcZ9COlJLQ4XFOeDMrBom+n9MfKsJLJ06bwKLm8kUmMjBG3+4oX/DyfM25Pr/fWtm/DhtzED/9WN8UDxHgud4m+at2+RoLtGX+AX2rqZ/4FN7feup2LBlxcUNPcUE1xgE+gzX0Jv2cIXjTnyIzPHG2uNVV9cLStyGz+JpCkHbsfSuxI86z5+tzg1Z8TWj4l4Kig1yyXEi28cUUrgxL8SrzsypAY9ekP5dRJIwCNu9SvfBkNsrT3N2yWpMSwukeqWQyx8wAoThNK7nrntjpTAzQua9FzT8eEYtSYuHIa0mvmbQFIjjJEZCknAcDJydulEeJvARt+UkUkjyyTpbqsiKgcvEJDLGVOWjUkKxI2OfTdiMz8TXvxVMfEfhtba8gtknDxzCPRM4CqOZIY2JxthSCevSnzfs/QSXCF7o8hI2KrFCHk5kkiBoy0mhkxEWzkEDIO4IoAyBuqg9xWj4j4OijsfjFmkGY0mQSxqEdZXKpEHVs83SAxAyBn0Oa9s/BiPBZSM8+u7ZFGhIjHHrk0jUWYP8AkDNsD0oAxs0+W+VTWWm/A/Daz8TeyEjCNXnXmAAuVh14bB2yxUfenkfgAG9W3MzpFyY5nd0UPE0zcuOFgrFC5cruDjGfTNIDHc+uN3Wv4d4BD20ks00kbRvcx50KYk+GyC0jFgVDMCox3ogfs1UxQOZZVeT4PWGjQpm5IEixkNnVGNTHUMEAbnOwMxAvT61enECO9bK0/Z1DJLNEHuxyTChzHCSxmkZBIoVz+GAusk4IXO1AWvgeIPFFJeHmXLSrbcuMPGUjZlWWRteyvp2C5wCN/QAVQcUI70dHxnHesnLlHZG6ozKcbjKkg4PptXomooLNmOPDHWlnEeIhwcVnjIai0hoURORNwSaOsGKkMBj096oRcgUx4XE8jqmc5O2T0+tKbwVCOTfXJ+It5v4jHHOv+eFcsAPUoZBWUi6D0rYcJkCSRIQMFlQnvpYGNh8sMaxxjMbtGf3GZT81On+lYJUqNrtjS1O3zosFlwyfmB/TuKX2jY2+tNIBWbNYujT2HERIgGd/5V49hITkPtWXZ5I21J9R60QfE7AYKnNTzyV+DQfByfxr9q6s1/xRJ/Cf0rynS6DJ8xL1oZOPcQ+IPEzE2WBRZDFJyBqjEX4fYHAA2PWlF4g32/pX0yTjls/xt2ly0sLQwxCyOU5K5jViqOQjadDkcvP5z65rtOAya+IuKM7q1pzTohgmjktXkDmPJhaVCP8AmbnB2z6bDEf+JuKJLJFLBzZJmEwinttZVo1KrJFEV20qmMgEYT2NbG28Y8PjujILrmCe5a5kbkzKIkS3dIoiNJZ21su4GMA9Ns5HgvHLeLibTSTJy2ikRJI1uXjid4yuQs34pGS2fdjjamAOnibiItVUQgxCPRzvh8MbdZN4zKBjk6jpIGBvjNES+N+JGVQ0SmZmeSHML8xOfHozAM50ldxsfrWgtvGtjbwchXE6Rw29vgxSLzleWRrsqGHlGhlxqIJNAJ4msxxO6kWcxwva/DW1wEcmJhFGok0hQ4OVcZAB3980AZ/iPFuIZge6hZzaZXXcQu5PNbUFnMn5v+nOD6etNY/EHFHEifALIjJCpiNnI0caRhmhVUXovmZhnOc+ldf8Tt5OHzWzcSMsvPWVXkjuSZY44AFjXUraRzGYDUR0ycZp3x3xbZzQ3kcVzGGeROVrS7T8OOzjRWQxIMNzNeA+3qCMUAZK447xCWE2jQFo2gt1CCKTUsUBzHMm+RnUAX6NsKYRcU4onww/w3L26pHC7WkxkCxA4XV36knHrTjjfjSzaC6SJvxUgitbWRUdeZE4hMqnKgqUeNyNWNjtmpweLrTnyE3WUWwjtIzKt0UeQ45jNy11g7YLDBOdjQBk4+OXkd5NOtpGkqxsk0YgdUVHwXeRM5UnUMsT3o9PEXGJB+DBIg/BcG3gkTEaIRDECg/5ONRC98tvivPCviWC1N+7lZTK0UaJplZZoTKwnCmTcDl9NZB3Gc4IrQcZ8U2Mlvcww3MYy0SQmRLxTyYbRFVlMSjziUuAH8uxyCMZAM+3ijikqaha6oZBPEQsEhjkN06mQbHBfWoxg5BJ9aJPiji4kXFlokURyOFtJQ0ixq0cZl/eKLlsdBkU3j8UWZu7a4HEJI7dFiU2YinCRiOI4DaBobDqhGA257Bc1Tw3xPaRtdGS6QxykNogW/WTUiMyNDNIQynmMcq2F3yMDIIAn4d4g4opL21lo1tFOeTbS6WxrCscZyr5cZ74ODtQo8VcRhj3gVBG8kccj2+Ht2lyzwxSMPwzgthTkgewpx/xXbJK5Sc6I+FraRELKA9wq4UY0jGCz+Y4G533r3jXiGwbh0tjHM7GNIXikaN9E04cyTSLldas3MdSXwPKMe4B83DVJTVYqS0xFoNeiorUxTJY0tEymffH1O39a2vAuGrFGJMhncZz/CP4RWd4AVWPDgHUTjPbpg/oa2FummNR7Z+9YSeToX6UUl8MD6EH7HNKPEMem8uB/wDtlP8A8nLf1pkw1MB6kD7nFC+JsfG3HpzG/TaoZUeSi2FObRNqTW1OrM7VjI2QYqDoaEmskO+KMziqnakMB+HT0rqtz7CvaAPnF8cAn2NfSLz9nVrqco50hYLcguxMV1LJCuvc+YFZgwXpnPtXzu8GMn03pvdcK4q0kqO0mqVIrmXMigSLrVYnznBYMVAA3BHtXecQT4g4BZi1u3hilheznS3DySa/iCWKtldICOMa8Lthh9HcfhGxW4tLZo0ZjEJbllnl5ilbZpGJjxpRGbRghs79KzvFuCcVuZFgml57xhiy/ExyCEJpDNL58RnzDdsE4PXFG3accReZJdadBdE1XMWpmCAlYhqzIxBGAuSc4oEJvAPB4bmW4NwqmOK3kl8ztGgYMgTW6AsF8x6A9Olbi1/ZrbPdXalJBCuiGEaidMrwCVpNXUouVAz1L4I2rLrYcYhnlkEpSZonlmYTxFtEOgOJCGOll1psfX2NdccJ4uZbXM4kkdi9tpuY5GJkDSNKuGJ0EI2X6bYzQA1XwTbDhaSyRsJ2iV+YHbWJZptECNDggIRkFjj8u2+cPJ/AHDeagVPw0mljlKzSMNEdq0hEmRmOQSaThcjSNzvisBDc8Ve7e1SSVrgfgsgYdIHZgCT5QqsWYHON/ej+KvxqAG5luXxGFQSLOjjEx6JpYg5Kb9/LQBoOB+EuHzwyzPCoRZZELRXErgRRW4keWLUuqVtbAadPr6br4PB9mP8A0rJIZDZ/GNd8zEaMVLBQmnSY9saicnJ6UIbPjQYyPc6OWUkLyXEUahriPAyzsBqKADHyoB+HcVMS2zSOIPhxdhGmCx8jKjJJbTgFl8h6ZG1AB3hrw1amGxaaGWd76SSIGNyiwJG+gvsp1t1ffbSp9N2f/A9rG8QdXkRIL24mlDMFdYpGWE5BwuAFzjrQXAOG8XsiFhlh0FGnMTXMLxNEVIaZk14EeP39hkDelUtlxNLSQCUC0UuwRLmMxsFYNJyhrPMRWcZ05Go9zmgC39ofCLSzZIIY05gCGRhLI8gPLVmEkbDSmouCCCdlPSsRTXi3H7q6Ci4neUISVDnOCdiR9qWAUAeYqQFegVICmI8AqQrgKkBTA9FWIuSBURR/BLIyzIg9csfRR1P9+tD4JXJpuFcHeRkJGmNcEk/vY3wPWtTPV42AA6DYCqnWsDcEsoQ80SnOC6jbruwpbxcaruc+ssp//tsVq/DkP46tt5dzlsbYOcD97pWSQmSVm7MzN9yT/Wsps1gsk7eHenNvH0qm2tsdqJXY4rFs2Juvah32ohvnQ8qZ7bUxFeBXVDRXUAYa7jyCPXattdftFR2lDwyFDLbPEfw9aQxyQvLC3mx5jCSME7uc4rJzpQMsNdSmcriam98X2ssl2siXLQ3aIrlVt4pYzFK8iKmjyuvnIJcljjfNUP4ms/g4rREu40jd3wotmZg06yr+Mw1RsqqN1AydjkVlWiqPJqtwtptOMeOIZEnVYpTLLbm3E8iwrJJqfUxl5eFwFAAwCTvnFUx+MrdMSLbyPIlnDYxh20oFXVznLI+sFg2FK4I33GayPJrwxUbg2moPi2D/ABG5uuVJybqFoZVUosic2NFkeM5Kk6kyMkfmNUS8XsPgZbNEu0VpROjEwsWZYRGokORhS+WIUHHr2rOGKolKNwbTe8U8d280V1GEnj50ismI7eT8NLVIQj8wnT5lZtS7gEYPWh+L/tDSSG7gET6ZI447Zm0aok0RJMjYOysYgwAzv19sUsVDXceCDTTsTVG9tPHNslw0umZV+CjsoyqROy6dJZijtoIyuwOfcUHd+Lrc2MtqqzSNIzsvOW3EcbPKXMsfLUMjEEeQeUEnHvh8VwFUSRAqYFepGT0BPyGak0ZHUEfMEUxHgFegVy1LFMVnAV6BXtdQI9Ar6F4Q4byouYR55N/kvYfXrSHw94ZaXEkmVj7Dozf6D3r6DHEAAAMAAAfIbVnOXo0hH2cBXpSphKJgsJJMhVPTO4wOvqf72qCyFjdxQHmySBM6kQEgZ8pZm37DA6eorOcCVXTWpHahf2ipy5YkJUcuPqNyzSMQc/RQce1Z604u8Q/CAAb907jPTUOmP5VEoOawXGai8n0BDjP86ky1kLLxUDpEikdmI/nitHbX8cg8rj5d/selYS05R5RtGcZcFxNcwqLNUNeTUFFmmurq6mBkWj2oaSKmLEVRKw7VsmZUL+RUeTRZFVZFVbJ2lIiqHLqxxXBDTFRSY6raMGi+WTsPpTWz8MzSbleWPV+v26/ypoHgz6p7UPxGMaM+h/2r6DbeEo13dmc+3lH6b/rRw4JEvSNfsCduhyauMWnZEpKqPk1rYySZ0LkDYnYAfMmm1jwHfLnOOw6fU9/0rdzWAA2UD5DFBwW3mq2yEhdb8PAGAAB6AYoxLT2pxBa0QbUVLKE6WMZ6xofmqn+lEjhURGOWg+SqP5CiVTBolBSGZDh/AAt6VK6osZGoZXftvWmh4fEhOiKNc9cKo/pRijfPepgUW2FUVolXhK5Fq9EyQAMk9KALLZ41DPLjlxjJPffouO+f51mb3xxzWaNdUUQ2/DALaT1BLZUE+uNtVX+LLrRFo1bA6m/zY8o+g3+o9KxNkirFrOdcmTjOCeu2Qdhgjr/SlVoLphfGglw2pdaxgBU1M0hxlsamLEtjfftn6VmXOk6c50k4OMZ+h6VpbOHmxNHk+XDLjHbc/fGKVT2WroPr0H2+/wDfSoUsEzzkXasjerrW5dAWB/LjHzJ/s1RNCUPr8q5j5FH8RLfbyj/urTkz4NVY+JkYYkyh9eq/ft9afW12jjIIPuDmvmQq2KRkOUYqfY4rGX08XwbR12uT6dzh/ea9r51/i8//AOU/p/pXVn9u+y/uEaF4qjyqNIB3oWR1GdwMdc9s4x/MfeoVmjoqKCoLAWOlVJPoASaLS4iGnHnJ/N1AXfoMdabm6Q40KFwMYAwD6H59j8qqmQ5IXW3h6VgSdKAHB1HcfQb02svDkQ/5rM3y8o/Tf9arjvW5mS2/9jGOmKcK/SrjHslyCLKzijGI41X1I6n69aYpDQtu9HxtWsUZs4QVB7eilaouaskS3cO1JBgPWivzsaxfEbvQ4rORSNRFjFeu9KLfiIKjerjdj1pFF8teo1CG5B7161yqjUzAAdzQAepqTyBRliAPes5Lx/UDygNC7NK2dC/bdm9FG5qhOIfEMI4gT3llk06wg3LxpnCp1BABbpUt0NKzZ8PZJCSWGkDJO4Vd8eduin2Jz7VBeLu0jJboFiXZpSCxc+ik+/0wc1m5bt2/CjcpEuFVWOotjqzk51OT3PTb0pnw4aAI9RP7zZOdz2qab5KuK4EPjqTSiJnLMct82P8A5pRJAvLUgebCjv6d8nY57D13xXniy65lzjqFIpryw4UkABQoGNgceh7Hc7n7VbxRCzYNwdtJBIyD6HFX8Y4cy4ljO3Vl6g+/3NexxafTPr1AHoPtTMTkxt0PlIGfl6UWBjJRq8x3Oc7jfoP5elLrhdyetaKBBIudsnY/5h/4pdc2/UY3XOR3xVxZMkKeVn8tQOR1qyRCpyOlSLahn71oZUUa66rK6gBlc8TdmPmwBjGO/v8APfP0oMSnGO2QffYEdfTf+VDFs1JWqVFItybGdm+KeW822azEEm9NI7jAqJIqIyS684rRxXGwrCfEebNaC2u9utKh2aqC5o6O6rJx3nvRSX3vVoTNQt1XPdVnFv8A3r1r73qiRpdT7VhfErd6ez3lZzjT6wcVLGL7XiRAxmj4uIs3T+/nSEQqu7t9B/U16bh3BEYwg2J7f70mhpj254wsY66m/T/ehpJWYapyTkErEDp67Au2fKPYZPyoKFdGcE5PViDqI2O38IyPn713U4G/vSodhDTSSlUJGnYIi+VF9Aq9Pr1rT2dmIo+Wv5m8zkY3PZc/wjfbud/SgOGWqRYZt27bdD/U1c92c9aT+CrDWlEY7ZHtVkV1pRnz2NZ+4uN6nfXWISPUUJCsRQSF5S/Xfoa2lrcRuuHxHpIB1HGfTFY3hQGrf1rUyRJIulhkUSVii6GLJGSSHDAbDTjO/c1XGnmOMgHYA9TjvSZNEDZ6gnfO9G3HE43cNkZ2xjfI9B6VFNMrAtsgEklQtjByv160TcKHGQRq9enTsaW8YuMT6wMDAH+9NIAmkMN9u/r3q/klGfuISpKkY36elL3jKGtXdLHIN8K3Y9x88dqR3FvjIO/oexq1IiSAeZ7V1W/Cmuq7JyBE14HqB/vHX6e9fQeN+ILGSUtcWUykaVRZI9JCLNJI4OJEOTG0WNzp3UbbshmGSSiTPtWifinDMK8djIVDDWXXK6eahk8wlxkIwVRgAGUA/umq/wDFeHqYHjtJAI5leQsocNFGzLoyXw5IMJIIUagd/NUsZmlm3ptbXW3WipL/AIeZI8W0mQjiReWMc0xwon4YlBZA6SNpLKcy98YprecasXRs2koZUkRGaIKNRVkjeRhINwVi6g40OACW2MDyKUu/erVvfeqrXjEKooEbZVRk4Ug7oWByxyGYMC2AcEDG1STisWAuh3PLMYYrGGywIOFUkEbjGCCMd8knHyS/aa+Ndl4vveuN/wC9BXPHYiHwra20+bAIGCp2UuQozrOjcHKjIxQ3EOMrIsiRoSZH1L5QCE8pAwrHLZXHsC38WBS1JOsCeml7CLnjIHTc/pSe54kzd6XuxqSDv6fpWpkFQ46k6j2GNh889TRLSE9T06eg+lAw7bnoc4PbIxkfTI+4q1s77EYxnIO2emfSkMIMmfnRtqQu560rWQDvU0lz79em/Tc/pQFjl78461Fbrak5mz3qQl9KADXny1e3U+VxQWTnodzpG3Ujqvz3G3vXpJzgg5ODjBzv0296QE7F8GtBDde9Z5UKncEEbnIIwM4yfbO1FxzED59PfHWgC/ikuoUVaGONFbGWx+tLJGzXW0mjqMjtSaKL+JESAt3FSsZ8qBneiJdPLztkilXDXGrfp7U1lC9jFjXOQRg/rVsRJGQfb3HyoaZt8DP1/wBe9IZH4dfeurzVXVQhDFIUZXGMqQwzuMqcjI7jatxJxPiodlNp+UMD+C5TCgnZyfPsjY3OrJG+d8NTQ+JLwnPxMucg51dwNIP2NUQaCPivFEGBZuM4AJgmY5VQuxYk5/DBPqVLdcml7y3yvhrcxu2ca43TZh0HMOMeTb/KB02oVvEt42nNw4wMeXSpO7HLaQNR87bnfcnrVE/GrlmDNM7MucFsN1GCNxuKiatVX9lxltdht3c3jHDQ5yVYhUYqSGVgGKnB6LsT3HtixZrsqSYmG6Ego+c6zIPzZJBI37DYbZ3UJeTsN3fT0Pp0C4+wFWScUl6iR8nAJzucEkZ/+R+5rDxuqpG3kXNsbyXl5jPLPm1KcRt/CuSw7bAEE+/psOl9dtrZYgSo0nCMSNL5IG+SwLDI32AJ6ZpV/ik/aR9+u/XoN/XoPtXn+IyrjSxQei4XcjBbYdT601pOuELyLtjE3t0THFygpZkRAUK6yjqFTLHcasZ+e9Gu3EUYKLZyVJUFIpHDEBgcOM6/3t8nofes8/EpS6OZG1oQUbupUghh75AOfYUdDxi7CqvxEgVRpVdXRdJXHy0sR8jWi01WUiHqO8Nji8g4gzvF8IwB/DysbsoGFXIkO2nG+rphvlVEtzegupiAKHBUI2TqZh5Vzlh5G9hp9qEbxDeZLfFS5P8A1nvg/wDaP19TkCficxbUZHLHcnO5JBBJ9Thm6+tJ6UapJfyNaru22NZb+7KnVFsCGP4TbaW17k9spv8A5frVklxeBgeWCWC7hCy4ZmYaiDgdTnPbB670ifiEpBUyNhs5GdjnOfvqb71aOJznA5r4yD17gg5/QVD0n6SK8q7Y2juLrWzcgByCuooyrpUliPMdPZv19sVXMl1+KGjPmBDkRtgKqlTpI2C4Yn03zQ5u5dsyOcdNzt16en5j969a+lIYGRiGBByeoPUe3T+80lCSfCG5prllo49LsAqBQVwNJ6L0Gc5x1+59sey8clLA4QaTqGFPXDAZ33/N99xigkjruVWnih0Z+SXYZ/jUuQ3kyBj8u3QA7Z9h9qjLxeRiCwTKtrU6ejDocZwce/t6DAnLr3lUeKHSDfLsZJx+XfIjJP8A0/LO2faufickilGCYOOi46dMYPsKXBKuRaFpQTtIN8nyy9EqLDHUVdFRfJDCqsQtZTjHaorEB0o9rcj5UK4waaYmW2z429atuExQ++AfSpq4YHPWmFkMiur3TXUAZ411dXVRBclc9dXUMYTL0H99loGurqgplsFeXHWva6mL0U2/5hR56fWvK6hgip6Hk611dQDK1om2611dQIPrx66upFFidK6urqYEakK6upAdXq17XUAXx0bFXV1SMv7UrvetdXU0JkY/ymq0/NXV1UILrq6upDP/2Q==',
                              width: 100.0,
                              height: 100.0,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
